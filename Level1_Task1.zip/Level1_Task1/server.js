const express = require("express");

const app = express();

const PORT = 3000;


// Set EJS as the view engine

app.set("view engine", "ejs");


// Read form data

app.use(express.urlencoded({ extended: true }));


// Serve CSS and other static files

app.use(express.static("Test"));


// Home page

app.get("/", (req, res) => {

    res.render("index");

});


// Form submission

app.post("/submit", (req, res) => {

    const { name, email, age, course } = req.body;

    console.log("Form Data:");
    console.log("Name:", name);
    console.log("Email:", email);
    console.log("Age:", age);
    console.log("Course:", course);


    res.render("result", {

        name: name,
        email: email,
        age: age,
        course: course

    });

});


// Start server

app.listen(PORT, () => {

    console.log(
        `Server running at http://localhost:${PORT}`
    );

});